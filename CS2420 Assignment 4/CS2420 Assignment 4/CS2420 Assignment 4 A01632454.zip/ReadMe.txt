Dear grader, 
I programmed in Xcode on a mac.
The program executes in test.cpp. The function readFile will take each file and read it into a different hash map. The toString on the records will print the word and its frequency from the hash map. THE FREQUENCY COUNT OF EACH WORD STARTS AT 0.

	For example if the word dog was in the hashmap once, it would print in the console as:
       
dog, freq: 0
      
So dog shows up exactly once in the hashmap, not zero times. Also if the word fish were in the hash map 10 times, it would print in the console as:

fish, freq 9
